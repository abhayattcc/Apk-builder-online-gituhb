package com.my.gk;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {

    private MainBinding binding;
    private double mUploadMessage = 0;
    private android.webkit.ValueCallback<android.net.Uri[]> mFilePathCallback;
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        binding = MainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initialize(_savedInstanceState);
        initializeLogic();
    }

    private void initialize(Bundle _savedInstanceState) {

        binding.webview1.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
                final String _url = _param2;
                super.onPageStarted(_param1, _param2, _param3);
            }

            @Override
            public void onPageFinished(WebView _param1, String _param2) {
                final String _url = _param2;
                super.onPageFinished(_param1, _param2);
            }
        });

        binding.webview1.setWebChromeClient(new android.webkit.WebChromeClient() {

            // ── Handle target="_blank" links — open in external browser ────────
            @Override
            public boolean onCreateWindow(android.webkit.WebView view,
                                          boolean isDialog,
                                          boolean isUserGesture,
                                          android.os.Message resultMsg) {

                // Use a temporary WebView to extract the URL from the transport message
                android.webkit.WebView tempWebView = new android.webkit.WebView(MainActivity.this);
                tempWebView.setWebViewClient(new android.webkit.WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(android.webkit.WebView v, String url) {
                        openInExternalBrowser(url);
                        return true;
                    }

                    // API 24+ override
                    @Override
                    public boolean shouldOverrideUrlLoading(android.webkit.WebView v,
                            android.webkit.WebResourceRequest request) {
                        openInExternalBrowser(request.getUrl().toString());
                        return true;
                    }
                });

                // The transport carries the new URL — connect the temp view to receive it
                android.webkit.WebView.WebViewTransport transport =
                    (android.webkit.WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(tempWebView);
                resultMsg.sendToTarget();
                return true;
            }

            @Override
            public boolean onShowFileChooser(
                    android.webkit.WebView webView,
                    android.webkit.ValueCallback<android.net.Uri[]> filePathCallback,
                    android.webkit.WebChromeClient.FileChooserParams fileChooserParams) {

                if (mFilePathCallback != null) {
                    mFilePathCallback.onReceiveValue(null);
                    mFilePathCallback = null;
                }

                mFilePathCallback = filePathCallback;
                android.content.Intent intent = fileChooserParams.createIntent();

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (android.content.ActivityNotFoundException e) {
                    mFilePathCallback = null;
                    android.widget.Toast.makeText(MainActivity.this,
                        "Cannot open file chooser",
                        android.widget.Toast.LENGTH_SHORT).show();
                    return false;
                }

                return true;
            }
        });
    }

    /** Opens any URL in the device's default/external browser. */
    private void openInExternalBrowser(String url) {
        try {
            android.content.Intent intent =
                new android.content.Intent(android.content.Intent.ACTION_VIEW,
                    android.net.Uri.parse(url));
            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            android.widget.Toast.makeText(MainActivity.this,
                "No browser found to open link", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private void initializeLogic() {
        android.webkit.WebView webview1 = findViewById(R.id.webview1);

        android.webkit.WebSettings settings = webview1.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setCacheMode(android.webkit.WebSettings.LOAD_DEFAULT);
        settings.setDatabaseEnabled(true);
        // Required for onCreateWindow (target="_blank") to fire
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);

        webview1.setWebViewClient(new android.webkit.WebViewClient() {
            @Override
            public void onReceivedError(android.webkit.WebView view, int errorCode,
            String description, String failingUrl) { }

            @Override
            public boolean shouldOverrideUrlLoading(android.webkit.WebView view, String url) {
                return false;
            }
        });

        setupTTS(webview1);
        setupExport(webview1);

        webview1.loadUrl("file:///android_asset/index.html");
    }

    // ── Export handler ────────────────────────────────────────────────────────
    private void setupExport(final android.webkit.WebView webview1) {
        webview1.addJavascriptInterface(new AndroidExportInterface(this), "AndroidExport");
    }

    // ── TTS setup ─────────────────────────────────────────────────────────────
    private void setupTTS(final android.webkit.WebView webview1) {
        final android.speech.tts.TextToSpeech[] ttsEngine = {null};

        final java.util.Map<String, Runnable> ttsCallbacks =
            new java.util.concurrent.ConcurrentHashMap<>();

        final java.util.Queue<String[]> ttsQueue =
            new java.util.concurrent.ConcurrentLinkedQueue<>();

        final boolean[] ttsSpeaking = {false};

        ttsEngine[0] = new android.speech.tts.TextToSpeech(this,
        new android.speech.tts.TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == android.speech.tts.TextToSpeech.SUCCESS) {
                    ttsEngine[0].setLanguage(java.util.Locale.ENGLISH);
                }
            }
        });

        ttsEngine[0].setOnUtteranceProgressListener(
            new TtsProgressListener(webview1, ttsCallbacks, ttsSpeaking));

        webview1.addJavascriptInterface(
            new AndroidTTSInterface(ttsEngine, ttsSpeaking, this),
            "AndroidTTS");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
            android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (mFilePathCallback == null) return;

            android.net.Uri[] results = null;
            if (resultCode == Activity.RESULT_OK) {
                results = android.webkit.WebChromeClient.FileChooserParams
                              .parseResult(resultCode, data);
            }

            mFilePathCallback.onReceiveValue(results);
            mFilePathCallback = null;
        }
    }

    // =========================================================================
    // Inner class: Export Interface
    // Handles saving text, html, and base64 image files from JS to device storage
    // =========================================================================
    private class AndroidExportInterface {

        private final MainActivity activity;

        AndroidExportInterface(MainActivity activity) {
            this.activity = activity;
        }

        /**
         * Called from JS to save plain text.
         * JS usage:  AndroidExport.saveText(content, 'exported_text.txt');
         */
        @android.webkit.JavascriptInterface
        public void saveText(final String content, final String filename) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        String fname = (filename == null || filename.trim().isEmpty())
                            ? "exported_text.txt" : filename.trim();
                        writeToDownloads(content.getBytes("UTF-8"), fname, "text/plain");
                    } catch (Exception e) {
                        showToast("Export failed: " + e.getMessage());
                    }
                }
            });
        }

        /**
         * Called from JS to save HTML content.
         * JS usage:  AndroidExport.saveHtml(htmlContent, 'page.html');
         */
        @android.webkit.JavascriptInterface
        public void saveHtml(final String content, final String filename) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        String fname = (filename == null || filename.trim().isEmpty())
                            ? "exported_page.html" : filename.trim();
                        writeToDownloads(content.getBytes("UTF-8"), fname, "text/html");
                    } catch (Exception e) {
                        showToast("Export failed: " + e.getMessage());
                    }
                }
            });
        }

        /**
         * Called from JS to save a base64-encoded image (png/jpg/webp).
         * JS usage:  AndroidExport.saveImage(base64DataUrl, 'image.png');
         * base64DataUrl can be a full data URI like "data:image/png;base64,..."
         * or just the raw base64 string.
         */
        @android.webkit.JavascriptInterface
        public void saveImage(final String base64DataUrl, final String filename) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        String fname = (filename == null || filename.trim().isEmpty())
                            ? "exported_image.png" : filename.trim();

                        String base64 = base64DataUrl;
                        String mimeType = "image/png";

                        // Strip data URI prefix if present: "data:image/png;base64,..."
                        if (base64DataUrl.startsWith("data:")) {
                            int commaIdx = base64DataUrl.indexOf(',');
                            if (commaIdx != -1) {
                                String header = base64DataUrl.substring(5, commaIdx);
                                int semiIdx = header.indexOf(';');
                                if (semiIdx != -1) {
                                    mimeType = header.substring(0, semiIdx);
                                }
                                base64 = base64DataUrl.substring(commaIdx + 1);
                            }
                        }

                        byte[] bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
                        writeToDownloads(bytes, fname, mimeType);

                    } catch (Exception e) {
                        showToast("Image export failed: " + e.getMessage());
                    }
                }
            });
        }

        /**
         * Writes bytes to the public Downloads folder and notifies MediaStore.
         * Works on Android 4.4 through Android 14+.
         */
        private void writeToDownloads(byte[] bytes, String filename, String mimeType) {
            try {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    android.content.ContentValues values = new android.content.ContentValues();
                    values.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, filename);
                    values.put(android.provider.MediaStore.Downloads.MIME_TYPE, mimeType);
                    values.put(android.provider.MediaStore.Downloads.IS_PENDING, 1);

                    android.net.Uri collection =
                        android.provider.MediaStore.Downloads.getContentUri(
                            android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY);

                    android.net.Uri itemUri =
                        activity.getContentResolver().insert(collection, values);

                    if (itemUri != null) {
                        java.io.OutputStream os =
                            activity.getContentResolver().openOutputStream(itemUri);
                        if (os != null) {
                            os.write(bytes);
                            os.flush();
                            os.close();
                        }
                        values.clear();
                        values.put(android.provider.MediaStore.Downloads.IS_PENDING, 0);
                        activity.getContentResolver().update(itemUri, values, null, null);
                    }

                } else {
                    java.io.File downloadsDir = android.os.Environment
                        .getExternalStoragePublicDirectory(
                            android.os.Environment.DIRECTORY_DOWNLOADS);
                    if (!downloadsDir.exists()) downloadsDir.mkdirs();

                    java.io.File outFile = new java.io.File(downloadsDir, filename);
                    java.io.FileOutputStream fos = new java.io.FileOutputStream(outFile);
                    fos.write(bytes);
                    fos.flush();
                    fos.close();

                    android.media.MediaScannerConnection.scanFile(
                        activity,
                        new String[]{ outFile.getAbsolutePath() },
                        new String[]{ mimeType },
                        null);
                }

                showToast("Saved to Downloads: " + filename);

            } catch (Exception e) {
                showToast("Save failed: " + e.getMessage());
            }
        }

        private void showToast(final String msg) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    android.widget.Toast.makeText(activity, msg,
                        android.widget.Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    // =========================================================================
    // Inner class: TTS progress listener
    // =========================================================================
    private class TtsProgressListener
            extends android.speech.tts.UtteranceProgressListener {

        private final android.webkit.WebView wv;
        private final java.util.Map<String, Runnable> callbacks;
        private final boolean[] speaking;

        TtsProgressListener(android.webkit.WebView wv,
                            java.util.Map<String, Runnable> callbacks,
                            boolean[] speaking) {
            this.wv = wv;
            this.callbacks = callbacks;
            this.speaking = speaking;
        }

        @Override
        public void onStart(String utteranceId) { }

        @Override
        public void onDone(final String utteranceId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    wv.evaluateJavascript(
                        "window._attsOnEnd('" + utteranceId + "')", null);
                    callbacks.remove(utteranceId);
                    speaking[0] = false;
                }
            });
        }

        @Override
        public void onError(final String utteranceId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    wv.evaluateJavascript(
                        "window._attsOnEnd('" + utteranceId + "')", null);
                    callbacks.remove(utteranceId);
                    speaking[0] = false;
                }
            });
        }
    }

    // =========================================================================
    // Inner class: AndroidTTS Javascript Interface
    // =========================================================================
    private class AndroidTTSInterface {

        private final android.speech.tts.TextToSpeech[] engine;
        private final boolean[] speaking;
        private final MainActivity activity;

        AndroidTTSInterface(android.speech.tts.TextToSpeech[] engine,
                            boolean[] speaking,
                            MainActivity activity) {
            this.engine = engine;
            this.speaking = speaking;
            this.activity = activity;
        }

        @android.webkit.JavascriptInterface
        public void speak(final String text, final String lang, final String id) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (engine[0] == null) return;

                    java.util.Locale locale;
                    if (lang.equals("hi")) {
                        locale = new java.util.Locale("hi", "IN");
                    } else if (lang.equals("or")) {
                        locale = new java.util.Locale("or", "IN");
                    } else {
                        locale = java.util.Locale.ENGLISH;
                    }

                    int result = engine[0].setLanguage(locale);

                    if (result == android.speech.tts.TextToSpeech.LANG_NOT_SUPPORTED
                    || result == android.speech.tts.TextToSpeech.LANG_MISSING_DATA) {
                        if (lang.equals("or")) {
                            engine[0].setLanguage(new java.util.Locale("hi", "IN"));
                        } else {
                            engine[0].setLanguage(java.util.Locale.ENGLISH);
                        }
                    }

                    engine[0].setSpeechRate(0.75f);
                    engine[0].setPitch(1.0f);

                    android.os.Bundle params = new android.os.Bundle();
                    params.putFloat(
                        android.speech.tts.TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
                    engine[0].speak(text,
                        android.speech.tts.TextToSpeech.QUEUE_ADD, params, id);

                    speaking[0] = true;
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void stop() {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (engine[0] != null) {
                        engine[0].stop();
                        speaking[0] = false;
                    }
                }
            });
        }

        @android.webkit.JavascriptInterface
        public boolean isSpeaking() {
            return engine[0] != null && engine[0].isSpeaking();
        }
    }

}
