Place your .java source files here.
They will be moved into the correct package directory
and the package declaration will be updated automatically.
