Place your XML layout files here.
Example: activity_main.xml

The main layout should be named activity_main.xml
(or the name you use in your Java code).
