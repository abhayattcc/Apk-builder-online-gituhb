# Android APK Factory

**Advanced Java + XML only template** with full GitHub Actions automation.

Create modern Android apps (Material 3, ViewBinding, Edge-to-Edge, Splash Screen, Dark theme…) by just dropping files into the `input/` folder.

## Features of the Base Template

- Pure **Java** + **XML Views** (no Kotlin, no Compose)
- **Material Design 3** (DayNight + Dynamic Colors)
- **ViewBinding** enabled
- Edge-to-edge display + proper WindowInsets
- Official Splash Screen API
- Adaptive icons + monochrome support
- Light / Dark theme ready
- Java 17 + AGP 8.7
- minSdk 24 / targetSdk 35 (configurable)
- Clean, professional project structure

## Quick Start (Single Command)

```bash
# Clone this repository
git clone <your-repo-url> android-apk-factory
cd android-apk-factory

# Run the setup command
./scripts/setup.sh
```

This creates:

- `input/` folder with sample `config.json`
- `output/` folder
- Ready-to-edit structure

## How to Build a New APK

1. Edit `input/config.json`:

```json
{
  "project_name": "My Cool App",
  "apk_name": "MyCoolApp",
  "package_name": "com.mycompany.mycoolapp",
  "version_code": 1,
  "version_name": "1.0.0",
  "min_sdk": 24,
  "target_sdk": 35,
  "compile_sdk": 35,
  "app_name": "My Cool App"
}
```

2. Add your files:
   - `input/icon.png` → high-resolution square icon
   - `input/layouts/activity_main.xml` (+ any other layouts)
   - `input/java/*.java` → your Java classes
   - `input/assets/` → optional extra files

3. Commit & push **or** go to GitHub → Actions → **Build Custom APK** → Run workflow

4. Download the artifacts:
   - Debug APK
   - Signed APK (when signing secrets are configured)
   - Signed AAB
   - Full customized source ZIP

## Project Structure

```
android-apk-factory/
├── template/                 ← Advanced Java + XML base project
├── input/                    ← YOU put files here only
│   ├── config.json
│   ├── icon.png
│   ├── layouts/
│   ├── java/
│   └── assets/
├── scripts/
│   ├── setup.sh              ← Single setup command
│   └── customize.py          ← Automatic project customization
├── .github/workflows/
│   └── build.yml             ← GitHub Actions factory
└── output/                   ← Placeholder
```

## Signing (Optional but Recommended)

1. Run the keystore generation workflow (or create your own).
2. Add these repository Secrets:
   - `KEYSTORE_BASE64`
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS`
   - `KEY_PASSWORD`

Then release builds will be properly signed.

## Local Development

You can also open the `template/` folder directly in Android Studio after running setup and customize.

```bash
./scripts/setup.sh
python3 scripts/customize.py
# Then open template/ in Android Studio
```

## License

MIT – free to use and modify.
