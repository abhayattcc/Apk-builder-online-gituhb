#!/usr/bin/env python3
"""
Android APK Factory - Customize Script
Reads input/config.json + files and customizes the template project.
"""

import json
import os
import shutil
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TEMPLATE = ROOT / "template"
INPUT = ROOT / "input"
CONFIG_FILE = INPUT / "config.json"

def load_config():
    if not CONFIG_FILE.exists():
        print("No config.json found – using defaults")
        return {
            "project_name": "Template App",
            "apk_name": "TemplateApp",
            "package_name": "com.example.template",
            "version_code": 1,
            "version_name": "1.0",
            "min_sdk": 24,
            "target_sdk": 35,
            "compile_sdk": 35,
            "app_name": "Template App"
        }
    with open(CONFIG_FILE) as f:
        return json.load(f)

def update_file_content(path: Path, replacements: dict):
    if not path.exists():
        return
    content = path.read_text(encoding="utf-8")
    for old, new in replacements.items():
        content = content.replace(old, new)
    path.write_text(content, encoding="utf-8")

def main():
    print("=== Android APK Factory Customize ===")
    config = load_config()
    print(f"Package : {config['package_name']}")
    print(f"App name: {config.get('app_name', config['project_name'])}")

    package = config["package_name"]
    package_path = package.replace(".", "/")

    # 1. Update root settings.gradle
    update_file_content(TEMPLATE / "settings.gradle", {
        'rootProject.name = "TemplateApp"': f'rootProject.name = "{config["apk_name"]}"'
    })

    # 2. Update app/build.gradle
    app_gradle = TEMPLATE / "app" / "build.gradle"
    if app_gradle.exists():
        content = app_gradle.read_text(encoding="utf-8")
        content = re.sub(r'namespace\s+[\'"].*?[\'"]', f'namespace \'{package}\'', content)
        content = re.sub(r'applicationId\s+[\'"].*?[\'"]', f'applicationId "{package}"', content)
        content = re.sub(r'minSdk\s+\d+', f'minSdk {config["min_sdk"]}', content)
        content = re.sub(r'targetSdk\s+\d+', f'targetSdk {config["target_sdk"]}', content)
        content = re.sub(r'compileSdk\s+\d+', f'compileSdk {config["compile_sdk"]}', content)
        content = re.sub(r'versionCode\s+\d+', f'versionCode {config["version_code"]}', content)
        content = re.sub(r'versionName\s+[\'"].*?[\'"]', f'versionName "{config["version_name"]}"', content)
        app_gradle.write_text(content, encoding="utf-8")

    # 3. Update strings.xml app_name
    strings = TEMPLATE / "app/src/main/res/values/strings.xml"
    update_file_content(strings, {
        ">Template App<": f'>{config.get("app_name", config["project_name"])}<'
    })

    # 4. Create new package directory and move MainActivity
    java_src = TEMPLATE / "app/src/main/java"
    old_pkg_dir = java_src / "com/example/template"
    new_pkg_dir = java_src / package_path
    new_pkg_dir.mkdir(parents=True, exist_ok=True)

    # Move existing Java files and update package declaration
    if old_pkg_dir.exists():
        for java_file in old_pkg_dir.glob("*.java"):
            content = java_file.read_text(encoding="utf-8")
            content = re.sub(r'package\s+[\w.]+;', f'package {package};', content)
            content = content.replace("com.example.template.databinding", f"{package}.databinding")
            target = new_pkg_dir / java_file.name
            target.write_text(content, encoding="utf-8")
        # Remove old package tree carefully
        shutil.rmtree(java_src / "com", ignore_errors=True)

    # 5. Copy user layouts
    layouts_src = INPUT / "layouts"
    layouts_dst = TEMPLATE / "app/src/main/res/layout"
    if layouts_src.exists():
        for xml in layouts_src.glob("*.xml"):
            shutil.copy2(xml, layouts_dst / xml.name)
            print(f"Copied layout: {xml.name}")

    # 6. Copy user Java files
    java_input = INPUT / "java"
    if java_input.exists():
        for java_file in java_input.glob("*.java"):
            content = java_file.read_text(encoding="utf-8")
            content = re.sub(r'package\s+[\w.]+;', f'package {package};', content)
            target = new_pkg_dir / java_file.name
            target.write_text(content, encoding="utf-8")
            print(f"Copied Java: {java_file.name}")

    # 7. Copy assets
    assets_src = INPUT / "assets"
    assets_dst = TEMPLATE / "app/src/main/assets"
    if assets_src.exists() and any(assets_src.iterdir()):
        assets_dst.mkdir(exist_ok=True)
        for item in assets_src.iterdir():
            if item.is_file():
                shutil.copy2(item, assets_dst / item.name)
                print(f"Copied asset: {item.name}")

    # 8. Icon handling (simple copy for now – advanced resize can be added later)
    icon = INPUT / "icon.png"
    if icon.exists():
        # Place as drawable for now (full density generation can be improved)
        drawable = TEMPLATE / "app/src/main/res/drawable"
        shutil.copy2(icon, drawable / "ic_launcher_foreground.png")
        print("Copied custom icon")

    print("Customization finished successfully.")

if __name__ == "__main__":
    main()
