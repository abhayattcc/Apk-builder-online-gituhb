#!/bin/bash
set -e

echo "=============================================="
echo "  Android APK Factory - Setup"
echo "  Pure Java + XML Advanced Template"
echo "=============================================="

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

# Create folders
mkdir -p input/{layouts,java,assets} output

# Create sample config.json
cat > input/config.json << 'CONFIG'
{
  "project_name": "My Java App",
  "apk_name": "MyJavaApp",
  "package_name": "com.mycompany.myjavaapp",
  "version_code": 1,
  "version_name": "1.0.0",
  "min_sdk": 24,
  "target_sdk": 35,
  "compile_sdk": 35,
  "main_activity": "MainActivity",
  "app_name": "My Java App"
}
CONFIG

# Create sample layout placeholder
cat > input/layouts/README.txt << 'TXT'
Place your XML layout files here.
Example: activity_main.xml

The main layout should be named activity_main.xml
(or the name you use in your Java code).
TXT

# Create sample Java placeholder
cat > input/java/README.txt << 'TXT'
Place your .java source files here.
They will be moved into the correct package directory
and the package declaration will be updated automatically.
TXT

echo ""
echo "Setup complete!"
echo ""
echo "Next steps:"
echo "  1. Edit   input/config.json     (package name, app name, SDKs...)"
echo "  2. Put    input/icon.png        (your app icon - high resolution square PNG)"
echo "  3. Put    input/layouts/*.xml   (your UI layouts)"
echo "  4. Put    input/java/*.java     (your Java source files)"
echo "  5. (Optional) put files in input/assets/"
echo ""
echo "Then either:"
echo "  - Push the input/ folder to GitHub and the Action will build automatically"
echo "  - Or go to Actions → Build Custom APK → Run workflow"
echo ""
echo "Outputs will appear as GitHub Actions Artifacts:"
echo "  - debug APK"
echo "  - signed APK"
echo "  - signed AAB"
echo "  - full source ZIP"
echo "=============================================="
